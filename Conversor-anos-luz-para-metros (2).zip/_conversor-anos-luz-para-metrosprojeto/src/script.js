var meuNome = "Wanderson";
var valorAnosLuz = 1;
var valorEmMetros = 9.461e15;
var resultadoEmMetros = valorAnosLuz * valorEmMetros;
//resultadoEmMetros = resultadoEmMetros.toFixed(2);

alert(
  "Olá " +
    meuNome +
    ", " +
    valorAnosLuz +
    " Ano Luz equivale a " +
    valorEmMetros +
    " Metros"
);
