// Variaveis 
var numeroSecreto = parseInt(Math.random() * 1001);
var numeroDeTentativas = 1;
var tentativas;

//Excluir o valor 0
if (numeroSecreto == 0){ numeroSecreto +=1 };


//Dificuldade
var dificuldade = prompt ("Por favor, escolha o nivel de dificuldade que deseja: 1) Fácil, 2) Médio, 3) Difícil");
 if (dificuldade == 1) {tentativas = 15}
 else if (dificuldade == 2) {tentativas = 10}
 else if (dificuldade == 3) {tentativas = 5}
 

//Loop do Chute
var i = 1
while (i <= tentativas){

  var chute = prompt("Tentativa " + i + " de " + tentativas + ". Chute um número de 1 a 1000:");

//Verifica Acerto e Erro
if (chute == numeroSecreto){
      alert("Parabéns você acertou");
    } 
   else if (chute > numeroSecreto){
      alert ("Poxaaa você errou 😞, acho que você devia chutar um numero mais baixo que " + chute);
    } 
   else if (chute < numeroSecreto){
      alert ("Ixeee rapaz tu chutou errado em, talvez se tu chutar um numero mais alto que " + chute + " quem sabe tu não acerta 🤔");
   }
  
//Verifica Tentativas
  if (chute != numeroSecreto){
    numeroDeTentativas += 1;
   }
  if (numeroDeTentativas > tentativas ) { alert ("Poxa você não consegui Acertar, o numero correto era " + numeroSecreto)}
  if (chute == null) { break }; 
i++
}




