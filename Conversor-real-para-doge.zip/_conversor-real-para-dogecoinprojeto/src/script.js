var meuNome = "Wanderson";
var valorDoReal = 500;
var valorDogeCoins = 0.45;
var valorEmReais = valorDogeCoins * valorDoReal;
valorEmReais = valorEmReais.toFixed(2);

alert(
  "Olá " +
    meuNome +
    "," +
    " R$ " +
    valorDoReal +
    " Reais vale " +
    valorDogeCoins +
    " DogeCoins"
);
